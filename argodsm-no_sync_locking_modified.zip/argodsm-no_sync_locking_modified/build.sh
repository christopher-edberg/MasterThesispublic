#! /bin/bash -l
#SBATCH -J build
#SBATCH -p cluster
#SBATCH -t 00:60:00
#SBATCH -o buildlog.out
#SBATCH -N 1

# Set up environment
ARGO_INSTALL_DIR=/home/christopher-edberg/Argo-nosync_mod/argodsm/install
export ARGO_LOAD_SIZE=8
export ARGO_ALLOCATION_POLICY=1
export ARGO_ALLOCATION_BLOCK_SIZE=16
export ARGO_MPI_WIN_GRANULARITY=16

# CMAKE configuration parameters
CMAKE_BUILD_STR="                                       \
        -DARGO_BACKEND_MPI=ON                   \
        -DARGO_BACKEND_SINGLENODE=OFF   \
        -DARGO_TESTS=ON                                 \
        -DARGO_TESTS_NPROCS=4                   \
        -DARGO_DEBUG=OFF                                \
        -DARGO_ENABLE_MT=ON                             \
        -DARGO_VM_SHM=OFF                               \
        -DARGO_VM_MEMFD=ON                              \
        -DBUILD_DOCUMENTATION=OFF               \
        -DCMAKE_C_COMPILER=mpicc                \
        -DCMAKE_CXX_COMPILER=mpicxx             \
        -DCMAKE_INSTALL_PREFIX=${ARGO_INSTALL_DIR} ../"


# If build/ does not exist
if [ ! -d "build/" ] ; then
    echo PREPARING...
    mkdir -p build
    echo ENTERING ARGO BUILDDIR...
    cd build
    echo CONFIGURING...
        cmake ${CMAKE_BUILD_STR}
# If clean was requested
elif [ "$1" = "clean" ] ; then
    echo PREPARING...
    rm -rf build
    mkdir -p build
    echo ENTERING ARGO BUILDDIR...
    cd build
    echo CONFIGURING...
        cmake ${CMAKE_BUILD_STR}
# Otherwise, if no argument was given
elif [ -z "$1" ] ; then
    echo PREPARING...
    mkdir -p build
    echo ENTERING ARGO BUILDDIR...
    cd build
fi
echo BUILDING...
make -j16
echo BUILD DONE, RUNNING TESTS...
make test
echo TESTS DONE, INSTALLING...
make install
echo INSTALL DONE
